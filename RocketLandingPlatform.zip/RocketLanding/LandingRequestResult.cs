﻿namespace RocketLanding;

public enum LandingRequestResult
{
    out_of_platform,
    clash,
    ok_for_landing
}