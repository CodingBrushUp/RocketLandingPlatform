﻿namespace RocketLanding;
public record LandingArea(int Width, int Height);