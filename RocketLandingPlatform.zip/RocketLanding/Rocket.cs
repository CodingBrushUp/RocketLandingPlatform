﻿using static RocketLanding.LandingRequest;

namespace RocketLanding;
public record class Rocket(Guid Id, Location Location);
